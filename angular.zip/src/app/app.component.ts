import { Component, OnInit } from '@angular/core';
import { Item } from './model/item';
import { ItemService } from './services/item.services';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class ItemListComponent implements OnInit{

  item: Item;
  list: Item[] = [];
  styleChange = 'nonChecked'; // Won't work since style would be globally changed
  name: string;
  errormsg: boolean = false;

  constructor (private itemserv: ItemService){

  }

  ngOnInit(): void {
    this.itemserv.getItems().subscribe((data) => {
      console.log(data);
      this.list = data;
    });

    //throw new Error('Method not implemented.');
  }


  addItem(){
    if(this.name){

      this.errormsg = false;
      this.item = new Item();
      this.item.itemName = this.name;
      console.log(this.item.itemName);
      console.log(this.item.ID);
      this.list.push(this.item);
      console.info(this.list);
      this.name=null;
    }else{
      this.errormsg = true;
    }
  }

  deleteItem(i: number){

    //var toDelete = this.list.indexOf(this.item);
    this.list.splice(i, 1);
  }

  statusChange(id, event){ //event?: MouseEvent

    if(event.target.checked){
      // this.styleChange = "checked";
      document.getElementById(id).style.textDecoration = 'line-through';
    }else{
      document.getElementById(id).style.textDecoration = 'none';
      // this.styleChange = "nonChecked";
    }
  }

}
