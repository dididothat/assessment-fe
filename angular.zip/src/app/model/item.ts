export class Item {
    ID: number;
    itemName: string;
}